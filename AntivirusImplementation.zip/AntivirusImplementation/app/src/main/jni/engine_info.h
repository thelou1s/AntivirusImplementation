/*
 * engine_info.h
 *
 *  Created on: Feb 26, 2013
 *      Author: cheng-foo.poon
 */

#ifndef ENGINE_INFO_H_
#define ENGINE_INFO_H_

const char* getEnginePath();
const char* getTempPath();
const char* getUpdatePath();

#endif /* ENGINE_INFO_H_ */
