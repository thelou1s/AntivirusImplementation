var classcom_1_1avira_1_1antivirusimplementation_1_1_scanner_callback =
[
    [ "ScannerCallback", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanner_callback.html#af3940315c7e37a35c9762583f1150d7b", null ],
    [ "addMalwareInfo", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanner_callback.html#abd6247198926f356d666a7f304b2f393", null ],
    [ "describeContents", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanner_callback.html#a266813c9b1a2d6bf45a418b41387cfa4", null ],
    [ "getFileInfo", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanner_callback.html#ad52d3079f3d4931ede1aa04ae32f36d3", null ],
    [ "getInfectedFileInfoList", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanner_callback.html#a9926813c0e712ef07c905e356aa37310", null ],
    [ "getTimeStamp", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanner_callback.html#a9937c7a5bbd98026c4604930e8f9ca75", null ],
    [ "writeToParcel", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanner_callback.html#a87749584e5ed3b8330f145e2811a6f0c", null ]
];