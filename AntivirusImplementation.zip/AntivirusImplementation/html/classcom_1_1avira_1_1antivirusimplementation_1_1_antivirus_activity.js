var classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus_activity =
[
    [ "onClick", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus_activity.html#a672dea91b4011c14264cfd03fe483c20", null ],
    [ "onCreate", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus_activity.html#a816743b40655ab31ad38707225dcf6a8", null ],
    [ "onResume", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus_activity.html#ab6fae08b2c5d835c2621a4130a53ee90", null ]
];