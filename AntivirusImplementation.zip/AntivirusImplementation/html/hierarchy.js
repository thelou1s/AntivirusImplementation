var hierarchy =
[
    [ "com.avira.antivirusimplementation.Antivirus", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus.html", null ],
    [ "com.avira.antivirusimplementation.AntivirusUtils", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus_utils.html", null ],
    [ "com.avira.antivirusimplementation.AppInfo", "classcom_1_1avira_1_1antivirusimplementation_1_1_app_info.html", null ],
    [ "OnClickListener", null, [
      [ "com.avira.antivirusimplementation.AntivirusActivity", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus_activity.html", null ]
    ] ],
    [ "ActionBarActivity", null, [
      [ "com.avira.antivirusimplementation.AntivirusActivity", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus_activity.html", null ]
    ] ],
    [ "Application", null, [
      [ "com.avira.antivirusimplementation.App", "classcom_1_1avira_1_1antivirusimplementation_1_1_app.html", null ]
    ] ],
    [ "BaseAdapter", null, [
      [ "com.avira.antivirusimplementation.ApplicationsAdapter", "classcom_1_1avira_1_1antivirusimplementation_1_1_applications_adapter.html", null ]
    ] ],
    [ "Parcelable", null, [
      [ "com.avira.antivirusimplementation.MalwareInfo", "classcom_1_1avira_1_1antivirusimplementation_1_1_malware_info.html", null ],
      [ "com.avira.antivirusimplementation.ScannedFileInfo", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanned_file_info.html", null ],
      [ "com.avira.antivirusimplementation.ScannerCallback", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanner_callback.html", null ]
    ] ]
];