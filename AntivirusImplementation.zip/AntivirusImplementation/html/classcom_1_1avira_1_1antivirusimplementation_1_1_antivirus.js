var classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus =
[
    [ "Antivirus", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus.html#a01065f9ba50e068c7741f15fbb622e8b", null ],
    [ "finalize", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus.html#a1e81ca54b1eabb5cc5f8b695da05b54c", null ],
    [ "getEngineVersion", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus.html#abbe374ed44caa0a2bbc33accd6bfd612", null ],
    [ "getVDFVersion", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus.html#a5c9dfcff4513f30c3e252e1c280bd2ea", null ],
    [ "onScanCallback", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus.html#a34018fa89db3ada6e3156c2d1ed4e2ab", null ],
    [ "scanApplication", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus.html#aa462dddafab4128e14e175f37ef9a217", null ]
];