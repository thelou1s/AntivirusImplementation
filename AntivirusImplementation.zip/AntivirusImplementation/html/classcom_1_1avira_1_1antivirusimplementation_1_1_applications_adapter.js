var classcom_1_1avira_1_1antivirusimplementation_1_1_applications_adapter =
[
    [ "ApplicationsAdapter", "classcom_1_1avira_1_1antivirusimplementation_1_1_applications_adapter.html#a69302a7dbf77c2428264b5dfc7985b57", null ],
    [ "getCount", "classcom_1_1avira_1_1antivirusimplementation_1_1_applications_adapter.html#a8c52c08fc4bde0dc20f54cb1cabe0f40", null ],
    [ "getItem", "classcom_1_1avira_1_1antivirusimplementation_1_1_applications_adapter.html#a03fc0091f6159e28f1faeec641fdbb43", null ],
    [ "getItemId", "classcom_1_1avira_1_1antivirusimplementation_1_1_applications_adapter.html#a2d4bfd015b50ca58b1da0ab09f31950f", null ],
    [ "getView", "classcom_1_1avira_1_1antivirusimplementation_1_1_applications_adapter.html#ab931bf9b39303cc5b8667cdfa32018bf", null ]
];