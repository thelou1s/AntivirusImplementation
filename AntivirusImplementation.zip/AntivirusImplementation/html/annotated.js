var annotated =
[
    [ "com", null, [
      [ "avira", null, [
        [ "antivirusimplementation", null, [
          [ "Antivirus", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus.html", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus" ],
          [ "AntivirusActivity", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus_activity.html", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus_activity" ],
          [ "AntivirusUtils", "classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus_utils.html", null ],
          [ "App", "classcom_1_1avira_1_1antivirusimplementation_1_1_app.html", "classcom_1_1avira_1_1antivirusimplementation_1_1_app" ],
          [ "AppInfo", "classcom_1_1avira_1_1antivirusimplementation_1_1_app_info.html", "classcom_1_1avira_1_1antivirusimplementation_1_1_app_info" ],
          [ "ApplicationsAdapter", "classcom_1_1avira_1_1antivirusimplementation_1_1_applications_adapter.html", "classcom_1_1avira_1_1antivirusimplementation_1_1_applications_adapter" ],
          [ "MalwareInfo", "classcom_1_1avira_1_1antivirusimplementation_1_1_malware_info.html", "classcom_1_1avira_1_1antivirusimplementation_1_1_malware_info" ],
          [ "ScannedFileInfo", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanned_file_info.html", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanned_file_info" ],
          [ "ScannerCallback", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanner_callback.html", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanner_callback" ]
        ] ]
      ] ]
    ] ]
];