var searchData=
[
  ['onscancallback',['onScanCallback',['../classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus.html#a34018fa89db3ada6e3156c2d1ed4e2ab',1,'com::avira::antivirusimplementation::Antivirus']]]
];
