var searchData=
[
  ['antivirus',['Antivirus',['../classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus.html#a01065f9ba50e068c7741f15fbb622e8b',1,'com::avira::antivirusimplementation::Antivirus']]]
];
