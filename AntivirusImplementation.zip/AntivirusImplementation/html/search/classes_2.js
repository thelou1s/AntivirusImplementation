var searchData=
[
  ['scannedfileinfo',['ScannedFileInfo',['../classcom_1_1avira_1_1antivirusimplementation_1_1_scanned_file_info.html',1,'com::avira::antivirusimplementation']]],
  ['scannercallback',['ScannerCallback',['../classcom_1_1avira_1_1antivirusimplementation_1_1_scanner_callback.html',1,'com::avira::antivirusimplementation']]]
];
