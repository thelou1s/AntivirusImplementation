var searchData=
[
  ['getengineversion',['getEngineVersion',['../classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus.html#abbe374ed44caa0a2bbc33accd6bfd612',1,'com::avira::antivirusimplementation::Antivirus']]],
  ['getinstance',['getInstance',['../classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus.html#ac4856ca2a124af9b42865b88f43250c0',1,'com::avira::antivirusimplementation::Antivirus']]],
  ['getvdfversion',['getVDFVersion',['../classcom_1_1avira_1_1antivirusimplementation_1_1_antivirus.html#a5c9dfcff4513f30c3e252e1c280bd2ea',1,'com::avira::antivirusimplementation::Antivirus']]]
];
