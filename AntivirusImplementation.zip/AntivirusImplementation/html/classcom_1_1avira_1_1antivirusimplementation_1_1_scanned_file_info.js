var classcom_1_1avira_1_1antivirusimplementation_1_1_scanned_file_info =
[
    [ "ScannedFileInfo", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanned_file_info.html#a9d44d7c6e00bb629fbfb9924c39cff21", null ],
    [ "addMalwareInfo", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanned_file_info.html#a9a773d1a4d9454b10f8735cce566aa77", null ],
    [ "describeContents", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanned_file_info.html#ab0822c45988cd0da2ce433488e779a84", null ],
    [ "getLevel", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanned_file_info.html#a399d5e5b1fc6c26a856fa57d389348c6", null ],
    [ "getMalwareInfoList", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanned_file_info.html#a60687dd60065b566c51ccc6e670038ba", null ],
    [ "getName", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanned_file_info.html#a5f806652d11249e3895534dea465aeb3", null ],
    [ "getPath", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanned_file_info.html#a1bf9da2289d22ad665c5dc0bc6d0fdba", null ],
    [ "getType", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanned_file_info.html#aade2ec4574cb79075fa5efb0f4332f4d", null ],
    [ "writeToParcel", "classcom_1_1avira_1_1antivirusimplementation_1_1_scanned_file_info.html#aa0aa403f0a526dd0aef28d5b8110d7f6", null ]
];