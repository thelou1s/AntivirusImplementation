var classcom_1_1avira_1_1antivirusimplementation_1_1_app_info =
[
    [ "AppInfo", "classcom_1_1avira_1_1antivirusimplementation_1_1_app_info.html#a18b1feca8a0811d801e9b6b76b2ebc8e", null ],
    [ "displayName", "classcom_1_1avira_1_1antivirusimplementation_1_1_app_info.html#a9d2b68f4f265b7bdaa9ab72b9a71d46b", null ],
    [ "packageName", "classcom_1_1avira_1_1antivirusimplementation_1_1_app_info.html#ab6be1b4548c565ddcab63b22fcf417a2", null ],
    [ "sourceDir", "classcom_1_1avira_1_1antivirusimplementation_1_1_app_info.html#a021d7b81714fe40c15071c8500c0d85f", null ]
];